#ifndef GLOBALVARIABLES_H_
#define GLOBALVARIABLES_H_

extern unsigned int verbose;

// ... You may not change this file

#endif